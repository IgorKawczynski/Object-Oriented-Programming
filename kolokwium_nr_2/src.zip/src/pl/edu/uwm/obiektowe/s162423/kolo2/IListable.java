package pl.edu.uwm.obiektowe.s162423.kolo2;

import java.util.Stack;

public interface IListable {

    public Stack<Product> getSortedByValue(boolean ascending);  // Stack - Stock ??
}
